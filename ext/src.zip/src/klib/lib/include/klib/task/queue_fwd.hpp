#pragma once

namespace klib::task {
class Queue;
} // namespace klib::task
