# bin2cpp

**Generate a C++ array embedding the bytes of a supplied file**

[LICENCE](LICENSE)
