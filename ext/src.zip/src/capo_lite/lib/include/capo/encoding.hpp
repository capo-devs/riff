#pragma once
#include <cstdint>

namespace capo {
enum class Encoding : std::int8_t { Wav, Mp3, Flac };
} // namespace capo
