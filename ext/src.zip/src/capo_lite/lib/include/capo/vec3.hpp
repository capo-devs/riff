#pragma once

namespace capo {
struct Vec3f {
	float x{};
	float y{};
	float z{};
};
} // namespace capo
